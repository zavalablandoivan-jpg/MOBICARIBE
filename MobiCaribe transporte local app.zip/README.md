
  # MobiCaribe transporte local app

  This is a code bundle for MobiCaribe transporte local app. The original project is available at https://www.figma.com/design/JopoAOn9haWeNnKLTcaeDM/MobiCaribe-transporte-local-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  