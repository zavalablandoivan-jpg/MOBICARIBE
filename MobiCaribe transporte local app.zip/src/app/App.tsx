import { useState, useEffect } from "react";
import {
  Home, Bell, User, Settings, ChevronRight, ChevronLeft,
  MapPin, Navigation, Clock, Calendar, Users, Star, Phone,
  CheckCircle, Plus, ArrowRight, Filter, Search, DollarSign,
  Shield, FileText, HelpCircle, LogOut, Car, X, TrendingUp,
  Compass, Lock, Eye, EyeOff, ClipboardList, Wallet, Activity,
  AlertCircle, Check, Zap, ChevronDown, Mail,
} from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import logoImg from "@/imports/create_a_colorful__professional__and_original_logo_for_a_mobile.png";

/* ─── PALETA ──────────────────────────────────────────────────────────────── */
const C = {
  primary:   "#0A6EBD",
  primaryDk: "#084E8A",
  secondary: "#00B4D8",
  success:   "#2E8B57",
  warning:   "#F4A300",
  error:     "#D62828",
  bg:        "#F8F9FA",
  text:      "#212529",
  muted:     "#6C757D",
  card:      "#ffffff",
  border:    "rgba(33,37,41,0.10)",
  surface:   "#EEF2F7",
} as const;

/* ─── TIPOS ───────────────────────────────────────────────────────────────── */
type Screen =
  | "splash" | "role" | "login" | "register"
  | "driver-main" | "route-form"
  | "client-search" | "client-results" | "route-detail" | "booking-confirm";
type DriverTab = "home" | "routes" | "reservations" | "notifications" | "profile";
type Role = "driver" | "client" | null;

interface Route {
  id: number; origin: string; destination: string; date: string;
  time: string; seats: number; price: string; driver: string;
  rating: number; phone: string; vehicle: string; active: boolean;
}

/* ─── DATOS MOCK ──────────────────────────────────────────────────────────── */
const ROUTES: Route[] = [
  { id: 1, origin: "Bilwi (Puerto Cabezas)", destination: "Siuna", date: "2026-06-19", time: "06:00", seats: 3, price: "C$280", driver: "Melvin Downs", rating: 4.9, phone: "+505 8312 4411", vehicle: "Toyota Hiace Blanca · NL-1234", active: true },
  { id: 2, origin: "Waspám", destination: "Bilwi (Puerto Cabezas)", date: "2026-06-19", time: "05:30", seats: 2, price: "C$350", driver: "Glenda Salgado", rating: 4.8, phone: "+505 8755 2230", vehicle: "Mitsubishi Rosa Azul · NL-5678", active: true },
  { id: 3, origin: "Rosita", destination: "Managua", date: "2026-06-20", time: "04:00", seats: 5, price: "C$520", driver: "Héctor Blandón", rating: 4.7, phone: "+505 8900 1122", vehicle: "Chevrolet Express Blanca · NL-9901", active: false },
];

const ACTIVITY = [
  { id: 1, type: "booking",   icon: CheckCircle, color: C.success, text: "Juan López confirmó reserva",    sub: "Bilwi → Siuna · Hace 20 min" },
  { id: 2, type: "trip",      icon: Car,         color: C.primary,  text: "Viaje completado exitosamente",  sub: "Waspám → Bilwi · Ayer 14:30" },
  { id: 3, type: "route",     icon: MapPin,      color: C.secondary,text: "Ruta publicada: Siuna → Bonanza",sub: "Hace 2 días" },
  { id: 4, type: "cancel",    icon: X,           color: C.error,    text: "Reserva cancelada por pasajero", sub: "Rosita → Bilwi · Hace 3 días" },
];

const RESERVATIONS = [
  { id: 1, name: "Juan López",   route: "Bilwi → Siuna",  time: "06:00", date: "19 Jun", status: "confirmed", seats: 1 },
  { id: 2, name: "Ana Herrera",  route: "Bilwi → Siuna",  time: "06:00", date: "19 Jun", status: "confirmed", seats: 2 },
  { id: 3, name: "Pedro Cruz",   route: "Siuna → Bonanza",time: "08:30", date: "20 Jun", status: "pending",   seats: 1 },
  { id: 4, name: "María Sotelo", route: "Waspám → Bilwi", time: "05:30", date: "19 Jun", status: "cancelled", seats: 1 },
];

const NOTIFICATIONS_DATA = [
  { id: 1, icon: CheckCircle, color: C.success, title: "Reserva confirmada",      body: "Juan López reservó 1 asiento para Bilwi → Siuna",  time: "Hace 20 min", read: false },
  { id: 2, icon: AlertCircle, color: C.warning, title: "2 asientos disponibles",  body: "Tu ruta Siuna → Bonanza tiene pocos asientos libres", time: "Hace 1 h",   read: false },
  { id: 3, icon: Car,         color: C.primary, title: "Ruta publicada",          body: "Tu nueva ruta Siuna → Bonanza ya está disponible",   time: "Hace 2 d",   read: true  },
  { id: 4, icon: X,           color: C.error,   title: "Reserva cancelada",       body: "María Sotelo canceló su reserva en Waspám → Bilwi",  time: "Hace 3 d",   read: true  },
];

/* ─── UTILITY COMPONENTS ──────────────────────────────────────────────────── */

function Toggle({ value, onToggle }: { value: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      className="relative flex-shrink-0 w-12 h-6 rounded-full transition-all duration-200"
      style={{ background: value ? C.primary : "#CBD5E0" }}
    >
      <span
        className="absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-md transition-all duration-200"
        style={{ left: value ? "26px" : "2px" }}
      />
    </button>
  );
}

function StatusBar({ light = false }: { light?: boolean }) {
  const col = light ? C.text : "#fff";
  return (
    <div className="flex items-center justify-between px-5 pt-2 pb-0.5" style={{ color: col }}>
      <span className="text-[13px] font-bold" style={{ fontFamily: "'Inter', sans-serif" }}>9:41</span>
      <div className="flex items-center gap-1.5">
        {/* Signal */}
        <svg width="15" height="11" viewBox="0 0 15 11" fill={col}>
          <rect x="0"  y="7" width="2.5" height="4"  rx="0.5"/>
          <rect x="4"  y="4.5" width="2.5" height="6.5" rx="0.5"/>
          <rect x="8"  y="2" width="2.5" height="9"  rx="0.5"/>
          <rect x="12" y="0" width="2.5" height="11" rx="0.5" opacity="0.3"/>
        </svg>
        <span className="text-[9px] font-bold tracking-tight">LTE</span>
        {/* WiFi */}
        <svg width="13" height="10" viewBox="0 0 13 10" fill="none" stroke={col} strokeWidth="1.5" strokeLinecap="round">
          <path d="M1 3C3.2 1 9.8 1 12 3"/>
          <path d="M2.5 5C4.2 3.5 8.8 3.5 10.5 5"/>
          <path d="M4.2 7C5 6.2 8 6.2 8.8 7"/>
          <circle cx="6.5" cy="9.2" r="0.9" fill={col} stroke="none"/>
        </svg>
        {/* Battery */}
        <svg width="22" height="11" viewBox="0 0 22 11" fill="none">
          <rect x="0.5" y="0.5" width="18" height="10" rx="2.5" stroke={col} strokeWidth="1"/>
          <rect x="2" y="2" width="13" height="7" rx="1.5" fill={col}/>
          <path d="M19.5 3.5V7.5" stroke={col} strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
        <span className="text-[9px] font-bold">92%</span>
      </div>
    </div>
  );
}

function GestureBar() {
  return (
    <div className="flex justify-center items-center py-2 flex-shrink-0">
      <div className="w-28 h-1 rounded-full" style={{ background: "rgba(33,37,41,0.18)" }} />
    </div>
  );
}

function BackBtn({ onBack, light = false }: { onBack: () => void; light?: boolean }) {
  return (
    <button onClick={onBack} className="flex items-center gap-1 text-sm font-semibold mb-4" style={{ color: light ? "rgba(255,255,255,0.8)" : C.muted }}>
      <ChevronLeft size={18} /> Atrás
    </button>
  );
}

function HeaderGradient({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div className="px-5 pt-2 pb-6 relative overflow-hidden flex-shrink-0" style={{ background: `linear-gradient(145deg, ${C.primary} 0%, ${C.primaryDk} 100%)`, ...style }}>
      <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full opacity-10" style={{ background: C.secondary }} />
      {children}
    </div>
  );
}

function SectionHeader({ title, action }: { title: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h3 className="font-bold text-base" style={{ color: C.text }}>{title}</h3>
      {action}
    </div>
  );
}

function Card({ children, className = "", style }: { children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return (
    <div className={`rounded-2xl border ${className}`} style={{ background: C.card, borderColor: C.border, boxShadow: "0 2px 10px rgba(0,0,0,0.06)", ...style }}>
      {children}
    </div>
  );
}

function InputField({ label, type = "text", placeholder, value, onChange, icon }: {
  label: string; type?: string; placeholder?: string;
  value: string; onChange: (v: string) => void; icon?: React.ReactNode;
}) {
  const [show, setShow] = useState(false);
  const isPass = type === "password";
  return (
    <div>
      <label className="block text-xs font-bold mb-1.5 tracking-wide uppercase" style={{ color: C.muted }}>{label}</label>
      <div className="relative">
        {icon && <div className="absolute left-3.5 top-1/2 -translate-y-1/2">{icon}</div>}
        <input
          type={isPass && show ? "text" : type}
          placeholder={placeholder}
          className="w-full rounded-xl py-3.5 text-base focus:outline-none focus:ring-2 border"
          style={{
            paddingLeft: icon ? "42px" : "14px",
            paddingRight: isPass ? "44px" : "14px",
            background: C.surface,
            borderColor: C.border,
            color: C.text,
            "--tw-ring-color": C.primary,
          } as React.CSSProperties}
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
        {isPass && (
          <button className="absolute right-3.5 top-1/2 -translate-y-1/2" onClick={() => setShow(!show)}>
            {show ? <EyeOff size={17} color={C.muted} /> : <Eye size={17} color={C.muted} />}
          </button>
        )}
      </div>
    </div>
  );
}

function PrimaryBtn({ label, onClick, full = true, color }: { label: string; onClick: () => void; full?: boolean; color?: string }) {
  return (
    <button
      onClick={onClick}
      className={`${full ? "w-full" : "px-6"} py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-95`}
      style={{ background: color ?? C.primary, boxShadow: `0 4px 16px ${(color ?? C.primary)}40` }}
    >
      {label}
    </button>
  );
}

function SettingRow({ icon, color, label, sub, onPress, danger = false }: {
  icon: React.ReactNode; color: string; label: string; sub?: string; onPress?: () => void; danger?: boolean;
}) {
  return (
    <button onClick={onPress} className="w-full flex items-center gap-3.5 py-3.5 px-4 text-left">
      <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: color + "18" }}>
        <span style={{ color }}>{icon}</span>
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold" style={{ color: danger ? C.error : C.text }}>{label}</p>
        {sub && <p className="text-xs" style={{ color: C.muted }}>{sub}</p>}
      </div>
      {!danger && <ChevronRight size={16} style={{ color: C.muted }} />}
    </button>
  );
}

/* ─── 1. SPLASH ───────────────────────────────────────────────────────────── */
function SplashScreen() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center relative overflow-hidden"
      style={{ background: `linear-gradient(160deg, ${C.primary} 0%, ${C.primaryDk} 55%, #032C52 100%)` }}>
      <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full opacity-10" style={{ background: C.secondary }} />
      <div className="absolute bottom-10 -left-16 w-56 h-56 rounded-full opacity-8" style={{ background: C.warning }} />
      <div className="absolute top-1/3 right-8 w-3 h-3 rounded-full opacity-40 bg-white" />
      <div className="absolute top-1/4 left-10 w-2 h-2 rounded-full opacity-30 bg-white" />

      <div className="relative z-10 flex flex-col items-center gap-7">
        <div className="p-4 rounded-3xl" style={{ background: "rgba(255,255,255,0.12)", backdropFilter: "blur(10px)", border: "1.5px solid rgba(255,255,255,0.2)", boxShadow: `0 0 50px rgba(0,180,216,0.3)` }}>
          <ImageWithFallback src={logoImg} alt="MobiCaribe" style={{ width: 100, height: 100, borderRadius: 22, objectFit: "contain" }} />
        </div>
        <div className="text-center">
          <h1 className="font-black text-white leading-none" style={{ fontSize: 38, letterSpacing: -0.5 }}>
            Mobi<span style={{ color: C.warning }}>Caribe</span>
          </h1>
          <p className="mt-2 font-semibold tracking-widest uppercase text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>Costa Caribe Norte · Nicaragua</p>
        </div>
        <div className="flex gap-2 mt-2">
          {[0, 1, 2].map((i) => (
            <div key={i} className="w-2 h-2 rounded-full"
              style={{ background: i === 1 ? C.warning : "rgba(255,255,255,0.3)", animation: `mPulse 1.4s ease-in-out ${i * 0.25}s infinite` }} />
          ))}
        </div>
      </div>
      <p className="absolute bottom-16 text-xs font-medium" style={{ color: "rgba(255,255,255,0.45)" }}>v2.0.0 · Listo para producción</p>
      <style>{`@keyframes mPulse{0%,100%{opacity:.35;transform:scale(1)}50%{opacity:1;transform:scale(1.4)}}`}</style>
    </div>
  );
}

/* ─── 2. ROLE SELECTION ───────────────────────────────────────────────────── */
function RoleScreen({ onSelect, onRegister }: { onSelect: (r: Role, flow: "login" | "register") => void; onRegister: () => void }) {
  const [selected, setSelected] = useState<Role>(null);

  const roles = [
    { id: "driver" as Role, emoji: "🚖", title: "Soy Conductor", sub: "Publica y gestiona tus rutas" },
    { id: "client" as Role, emoji: "🧍", title: "Soy Pasajero",  sub: "Busca y reserva tus viajes"  },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <HeaderGradient>
        <StatusBar />
        <div className="flex justify-center mt-5 mb-4">
          <ImageWithFallback src={logoImg} alt="MobiCaribe" style={{ width: 64, height: 64, borderRadius: 16, objectFit: "contain" }} />
        </div>
        <h2 className="text-center text-white text-xl font-black">¿Cómo deseas ingresar hoy?</h2>
        <p className="text-center text-xs mt-1" style={{ color: "rgba(255,255,255,0.65)" }}>Selecciona tu rol para continuar</p>
      </HeaderGradient>

      <div className="flex-1 overflow-y-auto px-5 py-6 flex flex-col gap-4">
        {roles.map(({ id, emoji, title, sub }) => {
          const isActive = selected === id;
          return (
            <button
              key={id}
              onClick={() => setSelected(id)}
              className="w-full rounded-2xl p-5 flex items-center gap-4 text-left transition-all active:scale-95 border-2"
              style={{
                background: isActive ? C.primary + "0F" : C.card,
                borderColor: isActive ? C.primary : C.border,
                boxShadow: isActive ? `0 4px 20px ${C.primary}22` : "0 2px 8px rgba(0,0,0,0.05)",
              }}
            >
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0"
                style={{ background: isActive ? C.primary + "18" : C.surface }}>
                {emoji}
              </div>
              <div className="flex-1">
                <p className="font-bold text-base" style={{ color: isActive ? C.primary : C.text }}>{title}</p>
                <p className="text-sm mt-0.5" style={{ color: C.muted }}>{sub}</p>
              </div>
              <div className="w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0"
                style={{ borderColor: isActive ? C.primary : C.border, background: isActive ? C.primary : "transparent" }}>
                {isActive && <Check size={13} color="#fff" />}
              </div>
            </button>
          );
        })}

        <div className="mt-2 flex flex-col gap-3">
          <button
            onClick={() => selected && onSelect(selected, "login")}
            className="w-full py-4 rounded-2xl font-bold text-base text-white transition-all active:scale-95"
            style={{
              background: selected ? C.primary : "#CBD5E0",
              boxShadow: selected ? `0 4px 16px ${C.primary}40` : "none",
              cursor: selected ? "pointer" : "not-allowed",
            }}
          >
            Iniciar sesión
          </button>
          <button
            onClick={() => selected ? onSelect(selected, "register") : undefined}
            className="w-full py-4 rounded-2xl font-bold text-base border-2 transition-all active:scale-95"
            style={{
              borderColor: selected ? C.primary : C.border,
              color: selected ? C.primary : C.muted,
              background: "transparent",
            }}
          >
            Crear cuenta nueva
          </button>
        </div>

        <div className="flex items-center gap-3 mt-2">
          <div className="flex-1 h-px" style={{ background: C.border }} />
          <span className="text-xs" style={{ color: C.muted }}>Costa Caribe Norte · Nicaragua</span>
          <div className="flex-1 h-px" style={{ background: C.border }} />
        </div>
      </div>
    </div>
  );
}

/* ─── 3. LOGIN ────────────────────────────────────────────────────────────── */
function LoginScreen({ role, onLogin, onRegister, onBack }: {
  role: Role; onLogin: () => void; onRegister: () => void; onBack: () => void;
}) {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const isDriver = role === "driver";

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <HeaderGradient style={{ background: isDriver ? `linear-gradient(145deg, ${C.primary}, ${C.primaryDk})` : `linear-gradient(145deg, ${C.secondary}, #007A95)` }}>
        <StatusBar />
        <BackBtn onBack={onBack} light />
        <div className="flex items-center gap-3">
          <ImageWithFallback src={logoImg} alt="MobiCaribe" style={{ width: 46, height: 46, borderRadius: 12, objectFit: "contain" }} />
          <div>
            <h2 className="text-white text-2xl font-black">Iniciar sesión</h2>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.65)" }}>{isDriver ? "Accede como conductor" : "Accede como pasajero"}</p>
          </div>
        </div>
      </HeaderGradient>

      <div className="flex-1 overflow-y-auto px-5 py-6 flex flex-col gap-5">
        <InputField label="Correo electrónico" type="email" placeholder="tucorreo@ejemplo.com" value={email} onChange={setEmail} icon={<Mail size={16} color={C.muted} />} />
        <InputField label="Contraseña" type="password" placeholder="••••••••" value={pass} onChange={setPass} icon={<Lock size={16} color={C.muted} />} />

        <button className="text-right text-sm font-semibold" style={{ color: C.primary }}>¿Olvidaste tu contraseña?</button>

        <PrimaryBtn label="Iniciar sesión" onClick={onLogin} color={isDriver ? C.primary : C.secondary} />

        <div className="text-center">
          <span className="text-sm" style={{ color: C.muted }}>¿No tienes cuenta? </span>
          <button onClick={onRegister} className="text-sm font-bold" style={{ color: isDriver ? C.primary : C.secondary }}>Crear cuenta</button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex-1 h-px" style={{ background: C.border }} />
          <span className="text-xs" style={{ color: C.muted }}>o continúa con</span>
          <div className="flex-1 h-px" style={{ background: C.border }} />
        </div>

        <button className="w-full py-3.5 rounded-2xl border-2 flex items-center justify-center gap-3 font-semibold text-sm transition-all active:scale-95" style={{ borderColor: C.border, color: C.text }}>
          <svg width="18" height="18" viewBox="0 0 18 18"><path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z"/><path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z"/><path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/><path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 6.29C4.672 4.163 6.656 3.58 9 3.58z"/></svg>
          Continuar con Google
        </button>
      </div>
    </div>
  );
}

/* ─── 4. REGISTER ─────────────────────────────────────────────────────────── */
function RegisterScreen({ role, onRegister, onBack }: { role: Role; onRegister: () => void; onBack: () => void }) {
  const [f, setF] = useState({ name: "", phone: "", email: "", pass: "" });
  const isDriver = role === "driver";

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <HeaderGradient>
        <StatusBar />
        <BackBtn onBack={onBack} light />
        <div className="flex items-center gap-3">
          <ImageWithFallback src={logoImg} alt="MobiCaribe" style={{ width: 46, height: 46, borderRadius: 12, objectFit: "contain" }} />
          <div>
            <h2 className="text-white text-2xl font-black">Crear cuenta</h2>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.65)" }}>{isDriver ? "Registro de conductor" : "Registro de pasajero"}</p>
          </div>
        </div>
      </HeaderGradient>

      <div className="flex-1 overflow-y-auto px-5 py-6 flex flex-col gap-4">
        <InputField label="Nombre completo" placeholder="Ej: Melvin Downs" value={f.name} onChange={(v) => setF({ ...f, name: v })} icon={<User size={16} color={C.muted} />} />
        <InputField label="Teléfono" type="tel" placeholder="+505 8300 0000" value={f.phone} onChange={(v) => setF({ ...f, phone: v })} icon={<Phone size={16} color={C.muted} />} />
        <InputField label="Correo electrónico" type="email" placeholder="tu@correo.com" value={f.email} onChange={(v) => setF({ ...f, email: v })} icon={<Mail size={16} color={C.muted} />} />
        <InputField label="Contraseña" type="password" placeholder="Mínimo 8 caracteres" value={f.pass} onChange={(v) => setF({ ...f, pass: v })} icon={<Lock size={16} color={C.muted} />} />

        {isDriver && (
          <div className="rounded-2xl p-4 border" style={{ background: C.primary + "0A", borderColor: C.primary + "30" }}>
            <p className="text-xs font-bold mb-1" style={{ color: C.primary }}>🚗 Conductor</p>
            <p className="text-xs" style={{ color: C.muted }}>Podrás agregar la información de tu vehículo después de registrarte.</p>
          </div>
        )}

        <PrimaryBtn label="Crear mi cuenta" onClick={onRegister} />
        <p className="text-center text-xs pb-2" style={{ color: C.muted }}>
          Al registrarte aceptas los{" "}
          <span style={{ color: C.primary }} className="font-semibold">Términos de uso</span>
          {" "}y la{" "}
          <span style={{ color: C.primary }} className="font-semibold">Política de privacidad</span>
        </p>
      </div>
    </div>
  );
}

/* ─── DRIVER BOTTOM NAV ───────────────────────────────────────────────────── */
function DriverBottomNav({ tab, onTabChange }: { tab: DriverTab; onTabChange: (t: DriverTab) => void }) {
  const items: { id: DriverTab; Icon: any; label: string }[] = [
    { id: "home",          Icon: Home,          label: "Inicio"    },
    { id: "routes",        Icon: Compass,        label: "Rutas"     },
    { id: "reservations",  Icon: ClipboardList,  label: "Reservas"  },
    { id: "notifications", Icon: Bell,           label: "Avisos"    },
    { id: "profile",       Icon: User,           label: "Perfil"    },
  ];

  return (
    <div className="flex items-center border-t flex-shrink-0" style={{ background: C.card, borderColor: C.border, boxShadow: "0 -4px 16px rgba(0,0,0,0.07)" }}>
      {items.map(({ id, Icon, label }) => {
        const active = tab === id;
        return (
          <button key={id} onClick={() => onTabChange(id)} className="flex-1 py-2 flex flex-col items-center gap-0.5 relative">
            {active && <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full" style={{ background: C.primary }} />}
            {id === "notifications" && (
              <div className="absolute top-1 right-[14%] w-2 h-2 rounded-full" style={{ background: C.error, border: "1.5px solid white" }} />
            )}
            <Icon size={22} strokeWidth={active ? 2.2 : 1.7} style={{ color: active ? C.primary : C.muted }} />
            <span className="text-[9.5px] font-semibold" style={{ color: active ? C.primary : C.muted }}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ─── 5. DRIVER DASHBOARD ─────────────────────────────────────────────────── */
function DriverDashboard({ onSettings, onNewRoute }: { onSettings: () => void; onNewRoute: () => void }) {
  const stats = [
    { icon: Car,         color: C.primary,   label: "Viajes",    value: "47"         },
    { icon: ClipboardList, color: C.secondary, label: "Reservas",  value: "12"         },
    { icon: DollarSign,  color: C.success,   label: "Ganancias", value: "C$14,800"   },
    { icon: Star,        color: C.warning,   label: "Valoración", value: "4.9 ★"     },
  ];

  return (
    <div className="flex flex-col h-full" style={{ minHeight: 0 }}>
      {/* Header */}
      <div className="px-5 pt-2 pb-6 relative flex-shrink-0"
        style={{ background: `linear-gradient(145deg, ${C.primary} 0%, ${C.primaryDk} 100%)` }}>
        <div className="absolute -top-6 -right-6 w-28 h-28 rounded-full opacity-10" style={{ background: C.secondary }} />
        <StatusBar />
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-3">
            <ImageWithFallback src={logoImg} alt="MobiCaribe" style={{ width: 40, height: 40, borderRadius: 10, objectFit: "contain" }} />
            <div>
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.65)" }}>Buenos días,</p>
              <h2 className="text-white font-bold text-lg leading-tight">Melvin Downs 👋</h2>
            </div>
          </div>
          <button onClick={onSettings} className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
            <Settings size={18} className="text-white" />
          </button>
        </div>

        {/* Stats 2×2 */}
        <div className="grid grid-cols-2 gap-2.5 mt-5">
          {stats.map(({ icon: Icon, color, label, value }) => (
            <div key={label} className="rounded-2xl p-3.5" style={{ background: "rgba(255,255,255,0.12)", backdropFilter: "blur(4px)" }}>
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
                  <Icon size={14} color="#fff" />
                </div>
                <span className="text-xs" style={{ color: "rgba(255,255,255,0.7)" }}>{label}</span>
              </div>
              <p className="text-white font-black text-lg leading-none">{value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-5 py-5 flex flex-col gap-5" style={{ minHeight: 0 }}>

        {/* Próxima salida */}
        <div>
          <SectionHeader title="Próxima salida" />
          <div className="rounded-2xl overflow-hidden" style={{ background: `linear-gradient(135deg, ${C.secondary}18, ${C.primary}12)`, border: `1.5px solid ${C.primary}25`, boxShadow: `0 4px 20px ${C.primary}15` }}>
            <div className="p-4 flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: C.primary }}>
                    <Navigation size={14} color="#fff" />
                  </div>
                  <span className="text-sm font-bold" style={{ color: C.primary }}>Mañana · 06:00 AM</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="font-medium" style={{ color: C.text }}>Bilwi</span>
                  <ArrowRight size={14} style={{ color: C.muted }} />
                  <span className="font-bold" style={{ color: C.text }}>Siuna</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs" style={{ color: C.muted }}>Pasajeros</p>
                <p className="font-black text-lg" style={{ color: C.primary }}>3<span className="text-sm font-semibold" style={{ color: C.muted }}>/4</span></p>
              </div>
            </div>
            <div className="mx-4 pb-4">
              <div className="w-full h-1.5 rounded-full" style={{ background: C.border }}>
                <div className="h-full rounded-full" style={{ width: "75%", background: `linear-gradient(90deg, ${C.primary}, ${C.secondary})` }} />
              </div>
              <p className="text-xs mt-1" style={{ color: C.muted }}>3 de 4 asientos reservados</p>
            </div>
          </div>
        </div>

        {/* Actividad reciente */}
        <div>
          <SectionHeader title="Actividad reciente" action={<button className="text-xs font-semibold" style={{ color: C.primary }}>Ver todo</button>} />
          <Card>
            {ACTIVITY.map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={item.id}>
                  <div className="flex items-center gap-3 p-3.5">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: item.color + "18" }}>
                      <Icon size={17} style={{ color: item.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold leading-tight truncate" style={{ color: C.text }}>{item.text}</p>
                      <p className="text-xs mt-0.5" style={{ color: C.muted }}>{item.sub}</p>
                    </div>
                  </div>
                  {i < ACTIVITY.length - 1 && <div className="mx-4 h-px" style={{ background: C.border }} />}
                </div>
              );
            })}
          </Card>
        </div>

        {/* Rutas activas */}
        <div className="pb-4">
          <SectionHeader title="Mis rutas activas" action={
            <button onClick={onNewRoute} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-white" style={{ background: C.warning }}>
              <Plus size={13} /> Nueva
            </button>
          } />
          <div className="flex flex-col gap-3">
            {ROUTES.filter(r => r.active).map((r) => (
              <Card key={r.id} className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2 text-xs mb-1" style={{ color: C.muted }}>
                      <MapPin size={11} style={{ color: C.primary }} />{r.origin}
                    </div>
                    <div className="flex items-center gap-2 text-sm font-bold" style={{ color: C.text }}>
                      <Navigation size={12} style={{ color: C.warning }} />{r.destination}
                    </div>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-full" style={{ background: "#D4EDDA", color: C.success }}>Activa</span>
                </div>
                <div className="flex items-center gap-4 pt-3 border-t text-xs" style={{ color: C.muted, borderColor: C.border }}>
                  <span className="flex items-center gap-1"><Clock size={11} />{r.time}</span>
                  <span className="flex items-center gap-1"><Calendar size={11} />{r.date}</span>
                  <span className="flex items-center gap-1"><Users size={11} />{r.seats} libres</span>
                  <span className="ml-auto font-black" style={{ color: C.primary }}>{r.price}</span>
                </div>
              </Card>
            ))}

            <button onClick={onNewRoute} className="w-full py-4 rounded-2xl border-2 border-dashed flex items-center justify-center gap-2 transition-all active:scale-95" style={{ borderColor: C.primary, color: C.primary }}>
              <Plus size={20} />
              <span className="text-sm font-bold">Publicar nueva ruta</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── 6. DRIVER ROUTES TAB ────────────────────────────────────────────────── */
function DriverRoutes({ onSettings, onNewRoute }: { onSettings: () => void; onNewRoute: () => void }) {
  const [filter, setFilter] = useState<"all" | "active" | "inactive">("all");
  const filtered = filter === "all" ? ROUTES : ROUTES.filter(r => filter === "active" ? r.active : !r.active);

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="px-5 pt-2 pb-5 flex-shrink-0" style={{ background: `linear-gradient(145deg, ${C.primary}, ${C.primaryDk})` }}>
        <StatusBar />
        <div className="flex items-center justify-between mt-2">
          <h2 className="text-white text-xl font-black">Mis Rutas</h2>
          <div className="flex gap-2">
            <button onClick={onNewRoute} className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold text-white" style={{ background: C.warning }}>
              <Plus size={13} /> Nueva
            </button>
            <button onClick={onSettings} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
              <Settings size={16} className="text-white" />
            </button>
          </div>
        </div>
        <div className="flex gap-2 mt-4">
          {(["all", "active", "inactive"] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)}
              className="px-3 py-1.5 rounded-xl text-xs font-bold transition-all"
              style={{ background: filter === f ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.1)", color: "white" }}>
              {f === "all" ? "Todas" : f === "active" ? "Activas" : "Inactivas"}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-3">
        {filtered.map((r) => (
          <Card key={r.id} className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="text-xs mb-1 flex items-center gap-1" style={{ color: C.muted }}><MapPin size={11} style={{ color: C.primary }} />{r.origin}</p>
                <p className="text-sm font-bold flex items-center gap-1" style={{ color: C.text }}><Navigation size={12} style={{ color: C.warning }} />{r.destination}</p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ background: r.active ? "#D4EDDA" : "#FFF3CD", color: r.active ? C.success : "#856404" }}>
                  {r.active ? "Activa" : "Inactiva"}
                </span>
                <span className="font-black text-sm" style={{ color: C.primary }}>{r.price}</span>
              </div>
            </div>
            <div className="flex items-center gap-3 pt-3 border-t text-xs" style={{ color: C.muted, borderColor: C.border }}>
              <span className="flex items-center gap-1"><Clock size={11} />{r.time}</span>
              <span className="flex items-center gap-1"><Calendar size={11} />{r.date}</span>
              <span className="flex items-center gap-1"><Users size={11} />{r.seats} asientos</span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ─── 7. DRIVER RESERVATIONS TAB ─────────────────────────────────────────── */
function DriverReservations({ onSettings }: { onSettings: () => void }) {
  const colors: Record<string, string> = { confirmed: C.success, pending: C.warning, cancelled: C.error };
  const labels: Record<string, string> = { confirmed: "Confirmada", pending: "Pendiente", cancelled: "Cancelada" };
  const bgs: Record<string, string> = { confirmed: "#D4EDDA", pending: "#FFF3CD", cancelled: "#F8D7DA" };

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="px-5 pt-2 pb-5 flex-shrink-0" style={{ background: `linear-gradient(145deg, ${C.primary}, ${C.primaryDk})` }}>
        <StatusBar />
        <div className="flex items-center justify-between mt-2">
          <h2 className="text-white text-xl font-black">Reservas</h2>
          <button onClick={onSettings} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
            <Settings size={16} className="text-white" />
          </button>
        </div>
        <div className="flex gap-4 mt-3">
          {[{ l: "Total", v: "4" }, { l: "Confirmadas", v: "2" }, { l: "Pendientes", v: "1" }].map(({ l, v }) => (
            <div key={l}>
              <p className="text-white font-black text-xl leading-none">{v}</p>
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>{l}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-3">
        {RESERVATIONS.map((res) => (
          <Card key={res.id} className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl flex items-center justify-center text-white font-black flex-shrink-0" style={{ background: C.primary }}>
                {res.name.split(" ").map(n => n[0]).join("")}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm" style={{ color: C.text }}>{res.name}</p>
                <p className="text-xs mt-0.5" style={{ color: C.muted }}>{res.route} · {res.time} · {res.date}</p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ background: bgs[res.status], color: colors[res.status] }}>
                  {labels[res.status]}
                </span>
                <span className="text-xs" style={{ color: C.muted }}>{res.seats} asiento{res.seats > 1 ? "s" : ""}</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ─── 8. NOTIFICATIONS TAB ────────────────────────────────────────────────── */
function NotificationsTab({ onSettings }: { onSettings: () => void }) {
  const [prefs, setPrefs] = useState({ all: true, reservas: true, cancelaciones: true, pasajeros: true, cambios: false, promos: false });
  const [showPrefs, setShowPrefs] = useState(false);

  const togglePref = (key: keyof typeof prefs) => setPrefs(p => ({ ...p, [key]: !p[key] }));

  const prefList = [
    { key: "reservas" as const, label: "Reservas nuevas" },
    { key: "cancelaciones" as const, label: "Cancelaciones" },
    { key: "pasajeros" as const, label: "Nuevos pasajeros" },
    { key: "cambios" as const, label: "Cambios de ruta" },
    { key: "promos" as const, label: "Promociones" },
  ];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="px-5 pt-2 pb-5 flex-shrink-0" style={{ background: `linear-gradient(145deg, ${C.primary}, ${C.primaryDk})` }}>
        <StatusBar />
        <div className="flex items-center justify-between mt-2">
          <h2 className="text-white text-xl font-black">Notificaciones</h2>
          <div className="flex gap-2">
            <button onClick={() => setShowPrefs(!showPrefs)} className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-white" style={{ background: "rgba(255,255,255,0.18)" }}>
              <Settings size={13} /> Preferencias
            </button>
            <button onClick={onSettings} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
              <Settings size={16} className="text-white" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-4">

        {/* Preferences panel */}
        {showPrefs && (
          <Card>
            <div className="p-4 border-b" style={{ borderColor: C.border }}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-bold text-sm" style={{ color: C.text }}>Todas las notificaciones</p>
                  <p className="text-xs" style={{ color: C.muted }}>Activar o desactivar todo</p>
                </div>
                <Toggle value={prefs.all} onToggle={() => togglePref("all")} />
              </div>
            </div>
            {prefList.map(({ key, label }) => (
              <div key={key} className="flex items-center justify-between p-3.5 border-b last:border-0" style={{ borderColor: C.border }}>
                <p className="text-sm" style={{ color: prefs.all ? C.text : C.muted }}>{label}</p>
                <Toggle value={prefs.all && prefs[key]} onToggle={() => prefs.all && togglePref(key)} />
              </div>
            ))}
          </Card>
        )}

        {/* Notification list */}
        <Card>
          {NOTIFICATIONS_DATA.map((n, i) => {
            const Icon = n.icon;
            return (
              <div key={n.id}>
                <div className="flex items-start gap-3 p-3.5" style={{ background: n.read ? "transparent" : C.primary + "05" }}>
                  {!n.read && <div className="w-1.5 h-1.5 rounded-full mt-1 flex-shrink-0" style={{ background: C.primary }} />}
                  {n.read && <div className="w-1.5 flex-shrink-0" />}
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: n.color + "18" }}>
                    <Icon size={17} style={{ color: n.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold" style={{ color: C.text }}>{n.title}</p>
                    <p className="text-xs mt-0.5" style={{ color: C.muted }}>{n.body}</p>
                    <p className="text-[10px] mt-1" style={{ color: C.muted }}>{n.time}</p>
                  </div>
                </div>
                {i < NOTIFICATIONS_DATA.length - 1 && <div className="mx-4 h-px" style={{ background: C.border }} />}
              </div>
            );
          })}
        </Card>
      </div>
    </div>
  );
}

/* ─── 9. PROFILE TAB ──────────────────────────────────────────────────────── */
function ProfileTab({ onSettings, onLogout }: { onSettings: () => void; onLogout: () => void }) {
  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="px-5 pt-2 pb-8 flex-shrink-0 relative overflow-hidden"
        style={{ background: `linear-gradient(145deg, ${C.primary}, ${C.primaryDk})` }}>
        <div className="absolute -bottom-6 -right-6 w-32 h-32 rounded-full opacity-10" style={{ background: C.secondary }} />
        <StatusBar />
        <div className="flex items-center justify-between mt-2 mb-4">
          <h2 className="text-white text-xl font-black">Mi Perfil</h2>
          <button onClick={onSettings} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
            <Settings size={16} className="text-white" />
          </button>
        </div>
        <div className="flex items-center gap-4">
          <div className="w-18 h-18 rounded-2xl flex items-center justify-center text-white font-black text-2xl flex-shrink-0 border-2 border-white/30"
            style={{ width: 72, height: 72, background: "rgba(255,255,255,0.2)", backdropFilter: "blur(8px)" }}>
            MD
          </div>
          <div>
            <h3 className="text-white font-black text-lg">Melvin Downs</h3>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.65)" }}>+505 8312 4411</p>
            <div className="flex items-center gap-1 mt-1">
              {[1,2,3,4,5].map(s => <Star key={s} size={11} className="fill-current" style={{ color: s <= 5 ? C.warning : "rgba(255,255,255,0.3)" }} />)}
              <span className="text-xs ml-1 text-white">4.9 · 47 viajes</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-4">
        <Card>
          <div className="p-4 flex gap-4">
            {[{ l: "Viajes", v: "47" }, { l: "Ganancias", v: "C$14,800" }, { l: "Años activo", v: "3" }].map(({ l, v }) => (
              <div key={l} className="flex-1 text-center">
                <p className="font-black text-base" style={{ color: C.primary }}>{v}</p>
                <p className="text-xs" style={{ color: C.muted }}>{l}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          {[
            { icon: <User size={17} />, color: C.primary, label: "Datos personales", sub: "Nombre, teléfono, correo" },
            { icon: <Car size={17} />,  color: C.secondary, label: "Mi vehículo", sub: "Toyota Hiace · NL-1234" },
            { icon: <Shield size={17} />, color: C.success, label: "Verificación", sub: "Licencia · DGT Nicaragua" },
          ].map(({ icon, color, label, sub }, i) => (
            <div key={label}>
              <SettingRow icon={icon} color={color} label={label} sub={sub} />
              {i < 2 && <div className="mx-4 h-px" style={{ background: C.border }} />}
            </div>
          ))}
        </Card>

        <button onClick={onLogout} className="w-full py-4 rounded-2xl border-2 flex items-center justify-center gap-2 font-bold text-sm transition-all active:scale-95" style={{ borderColor: C.error + "40", color: C.error, background: C.error + "08" }}>
          <LogOut size={17} /> Cerrar sesión
        </button>
      </div>
    </div>
  );
}

/* ─── SETTINGS OVERLAY ────────────────────────────────────────────────────── */
function SettingsScreen({ onClose, onLogout }: { onClose: () => void; onLogout: () => void }) {
  const sections = [
    { items: [
      { icon: <User size={17} />,     color: C.primary,   label: "Mi Perfil",              sub: "Melvin Downs · +505 8312 4411" },
      { icon: <Car size={17} />,      color: C.secondary, label: "Mi Vehículo",             sub: "Toyota Hiace Blanca · NL-1234" },
    ]},
    { items: [
      { icon: <Bell size={17} />,     color: C.warning,   label: "Notificaciones",          sub: "Reservas, cancelaciones y más" },
      { icon: <Lock size={17} />,     color: C.primary,   label: "Seguridad",               sub: "Contraseña y acceso biométrico" },
    ]},
    { items: [
      { icon: <FileText size={17} />, color: C.muted,     label: "Términos y Condiciones",  sub: undefined },
      { icon: <FileText size={17} />, color: C.muted,     label: "Política de Privacidad",  sub: undefined },
      { icon: <HelpCircle size={17}/>,color: C.success,   label: "Ayuda y Soporte",         sub: "Chat, email, teléfono" },
    ]},
  ];

  return (
    <div className="absolute inset-0 z-50 flex flex-col" style={{ background: C.bg }}>
      {/* Header */}
      <div className="px-5 pt-2 pb-5 flex-shrink-0" style={{ background: `linear-gradient(145deg, ${C.primary}, ${C.primaryDk})` }}>
        <StatusBar />
        <div className="flex items-center gap-3 mt-2">
          <button onClick={onClose} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
            <ChevronLeft size={20} className="text-white" />
          </button>
          <h2 className="text-white text-xl font-black">Configuración</h2>
        </div>
      </div>

      {/* Avatar */}
      <div className="px-5 py-5 flex items-center gap-4 border-b" style={{ background: C.card, borderColor: C.border }}>
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-white font-black text-xl" style={{ background: C.primary }}>MD</div>
        <div className="flex-1">
          <p className="font-bold text-base" style={{ color: C.text }}>Melvin Downs</p>
          <p className="text-sm" style={{ color: C.muted }}>melvin.downs@correo.com</p>
          <div className="flex items-center gap-1 mt-0.5">
            <Star size={11} className="fill-current" style={{ color: C.warning }} />
            <span className="text-xs" style={{ color: C.muted }}>4.9 · Conductor verificado ✓</span>
          </div>
        </div>
        <ChevronRight size={18} style={{ color: C.muted }} />
      </div>

      <div className="flex-1 overflow-y-auto py-4 flex flex-col gap-3">
        {sections.map((section, si) => (
          <Card key={si} className="mx-5">
            {section.items.map(({ icon, color, label, sub }, i) => (
              <div key={label}>
                <SettingRow icon={icon} color={color} label={label} sub={sub} />
                {i < section.items.length - 1 && <div className="mx-4 h-px" style={{ background: C.border }} />}
              </div>
            ))}
          </Card>
        ))}

        {/* App info */}
        <div className="px-5">
          <p className="text-center text-xs" style={{ color: C.muted }}>MobiCaribe v2.0.0 · Costa Caribe Norte · Nicaragua</p>
        </div>

        {/* Logout */}
        <div className="px-5 pb-4">
          <button
            onClick={onLogout}
            className="w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-bold text-sm transition-all active:scale-95 border-2"
            style={{ borderColor: C.error + "40", color: C.error, background: C.error + "08" }}
          >
            <LogOut size={17} /> Cerrar sesión
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── DRIVER SHELL (bottom nav wrapper) ───────────────────────────────────── */
function DriverShell({ tab, onTabChange, onSettings, onNewRoute, onLogout }: {
  tab: DriverTab; onTabChange: (t: DriverTab) => void;
  onSettings: () => void; onNewRoute: () => void; onLogout: () => void;
}) {
  return (
    <div className="flex-1 flex flex-col overflow-hidden" style={{ minHeight: 0 }}>
      <div className="flex-1 overflow-hidden" style={{ minHeight: 0 }}>
        {tab === "home"          && <DriverDashboard onSettings={onSettings} onNewRoute={onNewRoute} />}
        {tab === "routes"        && <DriverRoutes onSettings={onSettings} onNewRoute={onNewRoute} />}
        {tab === "reservations"  && <DriverReservations onSettings={onSettings} />}
        {tab === "notifications" && <NotificationsTab onSettings={onSettings} />}
        {tab === "profile"       && <ProfileTab onSettings={onSettings} onLogout={onLogout} />}
      </div>
      <DriverBottomNav tab={tab} onTabChange={onTabChange} />
    </div>
  );
}

/* ─── 10. ROUTE FORM ──────────────────────────────────────────────────────── */
function RouteForm({ onSave, onBack }: { onSave: () => void; onBack: () => void }) {
  const [f, setF] = useState({ origin: "", destination: "", date: "", time: "", seats: "4", price: "" });

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-5 pt-2 pb-5 flex-shrink-0" style={{ background: `linear-gradient(145deg, ${C.primary}, ${C.primaryDk})` }}>
        <StatusBar />
        <div className="flex items-center gap-3 mt-1">
          <button onClick={onBack} className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
            <ChevronLeft size={20} className="text-white" />
          </button>
          <div>
            <h2 className="text-white text-xl font-black">Nueva ruta</h2>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.65)" }}>Completa los datos del viaje</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-5 flex flex-col gap-4">
        <InputField label="📍 Origen" placeholder="Ej: Bilwi (Puerto Cabezas)" value={f.origin} onChange={(v) => setF({ ...f, origin: v })} />
        <InputField label="🏁 Destino" placeholder="Ej: Siuna" value={f.destination} onChange={(v) => setF({ ...f, destination: v })} />

        <div className="flex gap-3">
          <div className="flex-1">
            <label className="block text-xs font-bold mb-1.5 tracking-wide uppercase" style={{ color: C.muted }}>📅 Fecha</label>
            <input type="date" className="w-full rounded-xl py-3.5 px-4 text-base focus:outline-none border" style={{ background: C.surface, borderColor: C.border, color: C.text }} value={f.date} onChange={e => setF({ ...f, date: e.target.value })} />
          </div>
          <div className="flex-1">
            <label className="block text-xs font-bold mb-1.5 tracking-wide uppercase" style={{ color: C.muted }}>⏰ Hora</label>
            <input type="time" className="w-full rounded-xl py-3.5 px-4 text-base focus:outline-none border" style={{ background: C.surface, borderColor: C.border, color: C.text }} value={f.time} onChange={e => setF({ ...f, time: e.target.value })} />
          </div>
        </div>

        <div className="flex gap-3">
          <div className="flex-1">
            <label className="block text-xs font-bold mb-1.5 tracking-wide uppercase" style={{ color: C.muted }}>💺 Asientos</label>
            <select className="w-full rounded-xl py-3.5 px-4 text-base focus:outline-none border" style={{ background: C.surface, borderColor: C.border, color: C.text }} value={f.seats} onChange={e => setF({ ...f, seats: e.target.value })}>
              {[1,2,3,4,5,6,7,8].map(n => <option key={n} value={n}>{n} {n === 1 ? "asiento" : "asientos"}</option>)}
            </select>
          </div>
          <div className="flex-1">
            <InputField label="💰 Precio (C$)" placeholder="Ej: C$280" value={f.price} onChange={(v) => setF({ ...f, price: v })} />
          </div>
        </div>

        <div className="rounded-2xl p-4 border" style={{ background: C.warning + "0A", borderColor: C.warning + "30" }}>
          <p className="text-xs font-bold mb-1" style={{ color: C.warning }}>💡 Tip</p>
          <p className="text-xs" style={{ color: C.muted }}>Publicar rutas con anticipación aumenta tus posibilidades de llenar todos los asientos.</p>
        </div>

        <PrimaryBtn label="Publicar ruta" onClick={onSave} />
      </div>
    </div>
  );
}

/* ─── 11. CLIENT SEARCH ───────────────────────────────────────────────────── */
function ClientSearch({ dest, setDest, date, setDate, onSearch }: {
  dest: string; setDest: (v: string) => void;
  date: string; setDate: (v: string) => void;
  onSearch: () => void;
}) {
  const popular = [
    { name: "Siuna",         icon: "🏘️", routes: 6  },
    { name: "Bilwi",         icon: "🌊", routes: 9  },
    { name: "Waspám",        icon: "🌿", routes: 4  },
    { name: "Managua",       icon: "🏙️", routes: 5  },
    { name: "Bonanza",       icon: "⛏️", routes: 3  },
    { name: "Rosita",        icon: "🌺", routes: 4  },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-5 pt-2 pb-8 flex-shrink-0 relative overflow-hidden"
        style={{ background: `linear-gradient(145deg, ${C.secondary} 0%, #007A95 100%)` }}>
        <div className="absolute -top-10 -right-10 w-44 h-44 rounded-full opacity-10 bg-white" />
        <StatusBar />
        <div className="flex items-center justify-between mt-2 mb-5">
          <div className="flex items-center gap-2">
            <ImageWithFallback src={logoImg} alt="MobiCaribe" style={{ width: 36, height: 36, borderRadius: 9, objectFit: "contain" }} />
            <div>
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.65)" }}>Bienvenido 👋</p>
              <p className="text-white font-black text-base leading-tight">¿A dónde vas hoy?</p>
            </div>
          </div>
          <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.18)" }}>
            <User size={18} className="text-white" />
          </div>
        </div>

        {/* Search card */}
        <Card className="p-4 flex flex-col gap-0">
          <div className="flex items-center gap-3 py-1">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: C.primary + "18" }}>
              <Navigation size={16} style={{ color: C.primary }} />
            </div>
            <input type="text" placeholder="¿A qué destino viajas?" className="flex-1 text-base focus:outline-none" style={{ color: C.text }} value={dest} onChange={e => setDest(e.target.value)} />
          </div>
          <div className="h-px my-1" style={{ background: C.border }} />
          <div className="flex items-center gap-3 py-1">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: C.warning + "18" }}>
              <Calendar size={16} style={{ color: C.warning }} />
            </div>
            <input type="date" className="flex-1 text-base focus:outline-none" style={{ color: date ? C.text : C.muted }} value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div className="mt-3">
            <button onClick={onSearch} className="w-full py-3.5 rounded-xl text-white font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-95" style={{ background: C.primary }}>
              <Search size={18} /> Buscar rutas disponibles
            </button>
          </div>
        </Card>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-5">
        <SectionHeader title="Destinos populares" action={<span className="text-xs" style={{ color: C.muted }}>RACCN · Nicaragua</span>} />
        <div className="grid grid-cols-3 gap-3">
          {popular.map(({ name, icon, routes }) => (
            <button key={name} onClick={() => { setDest(name); onSearch(); }}
              className="rounded-2xl p-3 border text-center transition-all active:scale-95"
              style={{ background: C.card, borderColor: C.border, boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
              <span className="text-2xl">{icon}</span>
              <p className="font-bold text-xs mt-1.5" style={{ color: C.text }}>{name}</p>
              <p className="text-[10px]" style={{ color: C.muted }}>{routes} rutas</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── 12. ROUTE RESULTS ───────────────────────────────────────────────────── */
function RouteResults({ routes, onSelect, onBack }: { routes: Route[]; onSelect: (r: Route) => void; onBack: () => void }) {
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-5 pt-2 pb-5 flex-shrink-0" style={{ background: `linear-gradient(145deg, ${C.secondary}, #007A95)` }}>
        <StatusBar />
        <div className="flex items-center gap-3 mt-1">
          <button onClick={onBack} className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(255,255,255,0.15)" }}>
            <ChevronLeft size={20} className="text-white" />
          </button>
          <div className="flex-1">
            <h2 className="text-white text-xl font-black">Rutas disponibles</h2>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.65)" }}>{routes.length} resultado{routes.length !== 1 ? "s" : ""} encontrado{routes.length !== 1 ? "s" : ""}</p>
          </div>
          <button className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.15)" }}>
            <Filter size={16} className="text-white" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-3">
        {routes.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: C.surface }}>
              <Search size={28} style={{ color: C.muted }} />
            </div>
            <p className="font-bold" style={{ color: C.text }}>Sin resultados</p>
            <p className="text-sm" style={{ color: C.muted }}>Intenta con otro destino o fecha</p>
          </div>
        ) : routes.map((r) => (
          <button key={r.id} onClick={() => onSelect(r)} className="w-full text-left transition-all active:scale-95">
            <Card className="p-4">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: C.primary + "14" }}>
                  <Car size={20} style={{ color: C.primary }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-xs mb-0.5" style={{ color: C.muted }}>
                    <span className="truncate">{r.origin}</span>
                    <ArrowRight size={10} className="flex-shrink-0" />
                    <span className="font-bold text-sm truncate" style={{ color: C.text }}>{r.destination}</span>
                  </div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Star size={11} className="fill-current" style={{ color: C.warning }} />
                    <span className="text-xs" style={{ color: C.muted }}>{r.rating} · {r.driver}</span>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-black text-base" style={{ color: C.primary }}>{r.price}</p>
                  <p className="text-[10px]" style={{ color: C.muted }}>por persona</p>
                </div>
              </div>
              <div className="flex items-center gap-3 pt-3 border-t" style={{ borderColor: C.border }}>
                <span className="flex items-center gap-1 text-xs" style={{ color: C.muted }}><Clock size={11} />{r.time}</span>
                <span className="flex items-center gap-1 text-xs" style={{ color: C.muted }}><Calendar size={11} />{r.date}</span>
                <span className="ml-auto text-xs font-bold px-2 py-0.5 rounded-full"
                  style={{ background: r.seats <= 2 ? "#FFF3CD" : "#D4EDDA", color: r.seats <= 2 ? "#856404" : C.success }}>
                  {r.seats} libres
                </span>
              </div>
            </Card>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ─── 13. ROUTE DETAIL ────────────────────────────────────────────────────── */
function RouteDetail({ route, onBook, onBack }: { route: Route; onBook: () => void; onBack: () => void }) {
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Map-style header */}
      <div className="h-52 flex-shrink-0 relative overflow-hidden" style={{ background: `linear-gradient(160deg, ${C.primary} 0%, ${C.primaryDk} 60%, #032C52 100%)` }}>
        <div className="absolute inset-0 opacity-20"
          style={{ backgroundImage: `radial-gradient(circle at 20% 70%, ${C.secondary} 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(255,255,255,0.4) 0%, transparent 45%)` }} />
        <StatusBar />
        <button onClick={onBack} className="absolute top-9 left-5 flex items-center gap-1 text-sm rounded-xl px-3 py-1.5 font-semibold" style={{ color: "rgba(255,255,255,0.9)", background: "rgba(0,0,0,0.25)", backdropFilter: "blur(6px)" }}>
          <ChevronLeft size={16} /> Volver
        </button>
        {/* Route visual */}
        <div className="absolute bottom-5 left-5 right-5 flex items-center gap-4">
          <div className="flex flex-col gap-1.5">
            <div className="w-3 h-3 rounded-full bg-white" />
            <div style={{ width: 2, height: 24, borderLeft: "2px dashed rgba(255,255,255,0.45)", marginLeft: 5 }} />
            <div className="w-3 h-3 rounded-full" style={{ background: C.warning }} />
          </div>
          <div className="flex-1">
            <div>
              <p className="text-[10px] uppercase tracking-wide" style={{ color: "rgba(255,255,255,0.6)" }}>Origen</p>
              <p className="text-white font-bold text-sm">{route.origin}</p>
            </div>
            <div className="mt-2.5">
              <p className="text-[10px] uppercase tracking-wide" style={{ color: "rgba(255,255,255,0.6)" }}>Destino</p>
              <p className="text-white font-bold text-sm">{route.destination}</p>
            </div>
          </div>
          <ImageWithFallback src={logoImg} alt="" style={{ width: 52, height: 52, borderRadius: 14, objectFit: "contain", opacity: 0.9 }} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Trip info grid */}
        <div className="px-5 py-5 border-b" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg" style={{ color: C.text }}>Detalles del viaje</h3>
            <p className="font-black text-2xl" style={{ color: C.primary }}>{route.price}</p>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { Icon: Clock, label: "Hora", value: route.time },
              { Icon: Calendar, label: "Fecha", value: route.date.split("-").slice(1).reverse().join("/") },
              { Icon: Users, label: "Asientos", value: `${route.seats} libres` },
            ].map(({ Icon, label, value }) => (
              <div key={label} className="rounded-2xl p-3 text-center" style={{ background: C.surface }}>
                <Icon size={17} className="mx-auto mb-1" style={{ color: C.primary }} />
                <p className="text-[10px] uppercase tracking-wide" style={{ color: C.muted }}>{label}</p>
                <p className="text-sm font-bold mt-0.5" style={{ color: C.text }}>{value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Driver */}
        <div className="px-5 py-5 border-b" style={{ borderColor: C.border }}>
          <h3 className="font-bold mb-3" style={{ color: C.text }}>Conductor</h3>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-black text-lg flex-shrink-0" style={{ background: C.primary }}>
              {route.driver.split(" ").map(n => n[0]).join("")}
            </div>
            <div className="flex-1">
              <p className="font-bold" style={{ color: C.text }}>{route.driver}</p>
              <div className="flex items-center gap-0.5 mt-0.5">
                {[1,2,3,4,5].map(s => <Star key={s} size={12} className="fill-current" style={{ color: s <= Math.round(route.rating) ? C.warning : "#DEE2E6" }} />)}
                <span className="text-xs ml-1.5" style={{ color: C.muted }}>{route.rating} · 47 viajes</span>
              </div>
              <p className="text-xs mt-0.5" style={{ color: C.muted }}>{route.vehicle}</p>
            </div>
            <a href={`tel:${route.phone}`} className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: C.primary + "14" }}>
              <Phone size={18} style={{ color: C.primary }} />
            </a>
          </div>
        </div>

        {/* CTA */}
        <div className="px-5 py-5">
          <button onClick={onBook} className="w-full py-4 rounded-2xl text-white font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-95"
            style={{ background: `linear-gradient(135deg, ${C.secondary}, ${C.primary})`, boxShadow: `0 6px 20px ${C.primary}40` }}>
            Reservar asiento · {route.price}
          </button>
          <p className="text-center text-xs mt-3" style={{ color: C.muted }}>Sin cargos adicionales · Confirmación inmediata</p>
        </div>
      </div>
    </div>
  );
}

/* ─── 14. BOOKING CONFIRM ─────────────────────────────────────────────────── */
function BookingConfirm({ route, onDone }: { route: Route; onDone: () => void }) {
  const [code] = useState(`MC-${Math.floor(10000 + Math.random() * 90000)}`);

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-5 pt-2 pb-5 flex-shrink-0" style={{ background: `linear-gradient(145deg, ${C.success}, #1f6b3e)` }}>
        <StatusBar />
        <div className="flex flex-col items-center mt-3 gap-3">
          <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.2)", border: "3px solid rgba(255,255,255,0.5)" }}>
            <CheckCircle size={36} className="text-white" />
          </div>
          <div className="text-center">
            <h2 className="text-white text-2xl font-black">¡Reserva confirmada!</h2>
            <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.7)" }}>Tu asiento ha sido reservado exitosamente</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-5 flex flex-col gap-4">
        {/* Ticket */}
        <Card className="overflow-hidden">
          <div className="h-2" style={{ background: `linear-gradient(90deg, ${C.primary}, ${C.secondary}, ${C.warning})` }} />
          <div className="p-5 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-widest font-bold" style={{ color: C.muted }}>Código de reserva</p>
                <p className="font-black text-xl tracking-widest mt-0.5" style={{ color: C.text }}>{code}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] uppercase tracking-widest font-bold" style={{ color: C.muted }}>Total</p>
                <p className="font-black text-2xl mt-0.5" style={{ color: C.primary }}>{route.price}</p>
              </div>
            </div>

            <div className="h-px border-dashed border-t" style={{ borderColor: C.border }} />

            {/* Route */}
            <div className="flex items-stretch gap-4">
              <div className="flex flex-col items-center gap-1 py-0.5">
                <div className="w-3 h-3 rounded-full border-2" style={{ borderColor: C.primary }} />
                <div className="w-0.5 flex-1" style={{ borderLeft: `2px dashed ${C.border}` }} />
                <div className="w-3 h-3 rounded-full" style={{ background: C.warning }} />
              </div>
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-wide" style={{ color: C.muted }}>Origen</p>
                  <p className="font-bold text-sm" style={{ color: C.text }}>{route.origin}</p>
                </div>
                <div className="mt-3">
                  <p className="text-[10px] uppercase tracking-wide" style={{ color: C.muted }}>Destino</p>
                  <p className="font-bold text-sm" style={{ color: C.text }}>{route.destination}</p>
                </div>
              </div>
              <div className="text-right flex flex-col justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-wide" style={{ color: C.muted }}>Hora</p>
                  <p className="font-bold text-sm" style={{ color: C.text }}>{route.time}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wide" style={{ color: C.muted }}>Fecha</p>
                  <p className="font-bold text-sm" style={{ color: C.text }}>{route.date}</p>
                </div>
              </div>
            </div>

            <div className="h-px border-dashed border-t" style={{ borderColor: C.border }} />

            {/* Driver + status */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-black flex-shrink-0" style={{ background: C.primary }}>
                {route.driver.split(" ").map(n => n[0]).join("")}
              </div>
              <div className="flex-1">
                <p className="text-[10px] uppercase tracking-wide" style={{ color: C.muted }}>Conductor</p>
                <p className="font-bold text-sm" style={{ color: C.text }}>{route.driver}</p>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1" style={{ background: "#D4EDDA", color: C.success }}>
                <Check size={11} /> Confirmado
              </span>
            </div>
          </div>

          {/* Ticket footer */}
          <div className="mx-5 border-t border-dashed" style={{ borderColor: C.border }} />
          <div className="px-5 py-3 flex items-center justify-between">
            <ImageWithFallback src={logoImg} alt="MobiCaribe" style={{ width: 28, height: 28, borderRadius: 7, objectFit: "contain" }} />
            <p className="text-[10px] font-semibold" style={{ color: C.muted }}>MobiCaribe · RACCN · Nicaragua</p>
          </div>
        </Card>

        <div className="rounded-2xl p-4 border" style={{ background: C.primary + "08", borderColor: C.primary + "25" }}>
          <p className="text-xs font-bold mb-1" style={{ color: C.primary }}>📱 Cómo usar tu reserva</p>
          <p className="text-xs" style={{ color: C.muted }}>Presenta el código <strong>{code}</strong> al conductor al abordar el vehículo. También puedes llamar directamente al {route.phone}.</p>
        </div>

        <PrimaryBtn label="Volver al inicio" onClick={onDone} color={C.primary} />
      </div>
    </div>
  );
}

/* ─── APP ROOT ────────────────────────────────────────────────────────────── */
export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [role, setRole] = useState<Role>(null);
  const [driverTab, setDriverTab] = useState<DriverTab>("home");
  const [showSettings, setShowSettings] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [searchDest, setSearchDest] = useState("");
  const [searchDate, setSearchDate] = useState("");

  useEffect(() => {
    if (screen === "splash") {
      const t = setTimeout(() => setScreen("role"), 2800);
      return () => clearTimeout(t);
    }
  }, [screen]);

  const nav = (s: Screen) => setScreen(s);

  const filteredRoutes = ROUTES.filter(r => {
    const d = !searchDest || r.destination.toLowerCase().includes(searchDest.toLowerCase()) || r.origin.toLowerCase().includes(searchDest.toLowerCase());
    const dt = !searchDate || r.date === searchDate;
    return d && dt;
  });

  const handleLogout = () => { setRole(null); setShowSettings(false); setDriverTab("home"); nav("role"); };

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: "linear-gradient(135deg, #D6EAF8 0%, #AED6F1 50%, #85C1E9 100%)", fontFamily: "'Nunito', sans-serif" }}>

      {/* Phone frame */}
      <div style={{ position: "relative" }}>
        {/* Power button */}
        <div className="absolute right-0 top-32 w-1 h-14 rounded-l-full" style={{ background: "#2C3E50", right: "-3px" }} />
        {/* Volume buttons */}
        <div className="absolute left-0 top-24 w-1 h-10 rounded-r-full" style={{ background: "#2C3E50", left: "-3px" }} />
        <div className="absolute left-0 top-40 w-1 h-10 rounded-r-full" style={{ background: "#2C3E50", left: "-3px" }} />

        <div
          className="w-full relative overflow-hidden flex flex-col"
          style={{
            width: 390,
            minHeight: 780,
            borderRadius: "44px",
            background: C.bg,
            boxShadow: "0 32px 80px rgba(10,110,189,0.25), 0 8px 24px rgba(0,0,0,0.15), inset 0 0 0 2px rgba(255,255,255,0.15)",
            outline: "8px solid #1C1C1E",
          }}
        >
          {/* Camera punch hole */}
          <div className="absolute top-3.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full z-50" style={{ background: "#0A0A0A" }} />

          {/* Main content */}
          <div className="flex-1 flex flex-col overflow-hidden relative">
            {showSettings && <SettingsScreen onClose={() => setShowSettings(false)} onLogout={handleLogout} />}

            {screen === "splash"          && <SplashScreen />}
            {screen === "role"            && <RoleScreen onSelect={(r, flow) => { setRole(r); nav(flow === "register" ? "register" : "login"); }} onRegister={() => nav("register")} />}
            {screen === "login"           && <LoginScreen role={role} onLogin={() => nav(role === "driver" ? "driver-main" : "client-search")} onRegister={() => nav("register")} onBack={() => nav("role")} />}
            {screen === "register"        && <RegisterScreen role={role} onRegister={() => nav(role === "driver" ? "driver-main" : "client-search")} onBack={() => nav("login")} />}
            {screen === "driver-main"     && <DriverShell tab={driverTab} onTabChange={setDriverTab} onSettings={() => setShowSettings(true)} onNewRoute={() => nav("route-form")} onLogout={handleLogout} />}
            {screen === "route-form"      && <RouteForm onSave={() => nav("driver-main")} onBack={() => nav("driver-main")} />}
            {screen === "client-search"   && <ClientSearch dest={searchDest} setDest={setSearchDest} date={searchDate} setDate={setSearchDate} onSearch={() => nav("client-results")} />}
            {screen === "client-results"  && <RouteResults routes={filteredRoutes} onSelect={(r) => { setSelectedRoute(r); nav("route-detail"); }} onBack={() => nav("client-search")} />}
            {screen === "route-detail"    && selectedRoute && <RouteDetail route={selectedRoute} onBook={() => nav("booking-confirm")} onBack={() => nav("client-results")} />}
            {screen === "booking-confirm" && selectedRoute && <BookingConfirm route={selectedRoute} onDone={() => { setSelectedRoute(null); nav("client-search"); }} />}
          </div>

          {/* Android gesture bar */}
          <GestureBar />
        </div>
      </div>
    </div>
  );
}
